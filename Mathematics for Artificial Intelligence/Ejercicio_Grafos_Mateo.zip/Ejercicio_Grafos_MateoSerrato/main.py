import numpy as np

class Grafo:
    def __init__(self,dirigido,ponderado):
        self.__dirigido = dirigido
        self.__ponderado = ponderado
        self.__listas_adj = {}

    def es_dirigido(self):
        return self.__dirigido
    
    def es_ponderado(self):
        return self.__ponderado
    
    def agregar_vertice(self,v):
        if v not in self.__listas_adj:
            self.__listas_adj[v] = {}
            
    def agregar_arista(self,origen,destino,peso=1): #Recibe origen y destino que son los vertices que son unidos
        self.agregar_vertice(origen)
        self.agregar_vertice(destino)
        self.__listas_adj[origen][destino] = peso
        if not self.__dirigido:
            self.__listas_adj[destino][origen] = peso

    def vertices(self):
        return list(self.__listas_adj.keys())

    def vecinos(self, u):
        return list(self.__listas_adj.get(u, {}).keys())

        
    def existe_arista(self,u,v):
        try:
            self.__listas_adj[u][v]
            return True
        except KeyError:
            return False
        
    def obtener_peso(self,u,v):
        if self.existe_arista(u,v):
            return self.__listas_adj[u][v]
    
    def orden(self):
        return len(list(self.__listas_adj.keys()))
        
    def tamano(self):
        tamano = 0
        for n in self.__listas_adj:
            tamano += len(self.__listas_adj[n])

        if not self.es_dirigido():
            tamano //= 2  # dividir entre 2 si no es dirigido
        return tamano
        
    def grado(self,u):
        if self.__dirigido:
            return self.ingrado(u) + self.outgrado(u)
        else:
            return len(self.__listas_adj[u])
        
    def outgrado(self,u):
        return len(self.__listas_adj[u])

    def ingrado(self,u):
        if self.__dirigido:
            contador = 0
            for lista_nodo in self.__listas_adj:
                if u in self.__listas_adj[lista_nodo]:
                    contador += 1
            return contador
    
    def aristas(self):
        lista = []
        for u, lst_vecinos in self.__listas_adj.items():
            for v in lst_vecinos.keys():
                if self.__dirigido or (v, u) not in lista:
                    lista.append((u, v))
        return lista
    
    def bfs(self,origen,dest):
        q = [(origen,[origen])]
        visitados = set()
        visitados.add(origen)
        while q:
            n_actual,r_actual = q.pop(0)
            if n_actual == dest:
                return r_actual
            for v in self.vecinos(n_actual):
                if v not in visitados:
                    q.append((v,r_actual+[v]))
                    visitados.add(v)
        return None

    def dfs(self,origen,dest):
        q = [(origen,[origen])]
        visitados = set()
        visitados.add(origen)
        while q:
            n_actual,r_actual = q.pop(-1)
            if n_actual == dest:
                return r_actual
            for v in self.vecinos(n_actual):
                if v not in visitados:
                    q.append((v,r_actual+[v]))
                    visitados.add(v)
        return None

    def dijkstra(self, origen, destino):
        import heapq
        costo = {n: float('inf')
                 for n in self.vertices()}
        costo[origen] = 0
        prev = {n: None for n in self.vertices()}
        visitados = set()
        q = [(costo[origen], origen)]

        while q:
            costo_u, u = heapq.heappop(q)
            if u in visitados:
                continue
            visitados.add(u)
            if u == destino:
                break
            for v in self.vecinos(u):
                alt = costo_u + self.obtener_peso(u, v)
                if alt < costo[v]:
                    costo[v] = alt
                    prev[v] = u
                    heapq.heappush(q,(costo[v],v))
        if prev[destino] is None:
            return None, None 
        actual = destino
        ruta = []
        while actual != None:
            ruta.append(actual)
            actual = prev[actual]
        return ruta[::-1], costo[destino]

    def A_star(self,origen,destino,heuristica):
        import heapq
        g = {n: float('inf') for n in self.vertices()}
        g[origen] = 0
        f = {n: float('inf') for n in self.vertices()}
        prev = {p: None for p in self.vertices()}
        q = [(f[origen],origen)]
        visitados = set()
        while q:
            f_u, u = heapq.heappop(q)
            if u == destino:
                break 
            if u in visitados:
                continue
            for v in self.vecinos(u):
                alt = g[u] + self.obtener_peso(u,v)
                if alt < g[v]:
                    g[v] = alt
                    prev[v] = u
                    f[v] = g[v] + heuristica[v]
                    heapq.heappush(q,(f[v],v))
            
        if prev[destino] is None:
            return None, None
        actual = destino
        ruta = []
        while actual!= None:
            ruta.append(actual)
            actual = prev[actual]
        return ruta[::-1], g[destino]


    def calcular_h(self,posiciones,destino):
        dest = np.array(posiciones[destino])
        h = {}
        for n, pos in posiciones.items():
            origen = np.array(pos)
            dist = np.linalg.norm(origen-dest)
            h[n] = dist
        return h
    
    def mst_prim(self,origen = None):
        #inicializacion
        vertices = self.vertices()
        if origen is None:
            origen = vertices[0]
        T = Grafo(dirigido=self.es_dirigido(),ponderado=self.es_ponderado())
        T.agregar_vertice(origen)
        V = {v for v in vertices}
        V.remove(origen)
        #construccion MST
        n = len(vertices)
        total = 0
        for i in range(n-1):
            aristas = []
            for u in T.vertices():
                for v in self.vecinos(u):
                    if v in V:
                        peso = self.obtener_peso(u,v)
                        aristas.append((peso,(u,v)))
            aristas = sorted(aristas)
            menor_peso,(u,v) = aristas[0]
            total += menor_peso
            V.remove(v)
            T.agregar_arista(u,v,menor_peso)

        return T, total



                  








from graficar_grafo import graficar_pyvis, graficar_nx


g = Grafo(dirigido=False, ponderado=True)
g.agregar_arista("a", "b", 3)
g.agregar_arista("a", "c", 4)

g.agregar_arista("b", "d", 6)
g.agregar_arista("b", "e", 5)

g.agregar_arista("c", "e", 6)

g.agregar_arista("d", "e", 2)
g.agregar_arista("d", "z", 7)

g.agregar_arista("e", "z", 12)
ruta_bfs = g.bfs("a", "z")
ruta_dfs = g.dfs("a", "z")
print("La ruta dfs de a a z es:", ruta_dfs)
print("La ruta bfs de a a z es:", ruta_bfs)

graficar_pyvis(g)
graficar_nx(g)

ruta_dijkstra, costo = g.dijkstra("a", "z")
print("La ruta más corta de a a z es:", ruta_dijkstra, "con un costo de:", costo)

posiciones = {
"a": [0,1],
"b": [2,2],
"c": [2,0],
"d": [4,2],
"e": [4,0],
"z": [6,1]

}

h = g.calcular_h(posiciones,"z")


ruta_A_star, costo = g.A_star("a", "z",h)
print("La ruta más corta de a a z es:", ruta_A_star, "con un costo de:", costo)


