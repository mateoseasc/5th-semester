from main import Grafo
from graficar_grafo import *

g = Grafo(dirigido=False, ponderado=True)
g.agregar_arista("A","C",7)
g.agregar_arista("A","E",4)
g.agregar_arista("A","F",7)

g.agregar_arista("B","C",8)
g.agregar_arista("B","E",7)
g.agregar_arista("B","F",5)
g.agregar_arista("B","D",3)

g.agregar_arista("C","E",6)

g.agregar_arista("D","F",4)

graficar_nx(g)

mst, total = g.mst_prim("B")
graficar_nx(mst)
print(total)